
import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/word.dart';

class WordService {
  static List<Word>? _cache;

  static Future<List<Word>> getWords() async {
    if (_cache != null) return _cache!;

    final String response =
        await rootBundle.loadString('assets/data/words.json');

    final List<dynamic> data = jsonDecode(response);

    _cache = data
        .map((item) => Word.fromJson(item as Map<String, dynamic>))
        .toList();

    return _cache!;
  }

  static Future<List<Word>> getWordsByCategory(
      String category) async {
    final words = await getWords();

    return words
        .where((word) => word.category == category)
        .toList();
  }

  static Future<List<Word>> searchWords(String query) async {
    final words = await getWords();

    return words.where((word) {
      final q = query.toLowerCase();

      return word.derja.toLowerCase().contains(q) ||
          word.arabic.contains(query) ||
          word.english.toLowerCase().contains(q);
    }).toList();
  }

  static Future<Word?> getWordOfTheDay() async {
    final words = await getWords();

    if (words.isEmpty) return null;

    // Temporary selection for development.
    return words.first;
  }
}
