import 'package:flutter/material.dart';
import '../data/favorites_service.dart';
import '../data/word_service.dart';
import '../models/word.dart';
import '../widgets/word_card.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late final Future<List<Word>> _words;

  @override
  void initState() {
    super.initState();
    _words = WordService.getWords();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Word>>(
      future: _words,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Could not load words: ${snapshot.error}'));
        }

        final allWords = snapshot.data ?? const <Word>[];

        // Rebuilds whenever any heart is tapped anywhere in the app.
        return ListenableBuilder(
          listenable: FavoritesService.instance,
          builder: (context, _) {
            final favorites = allWords
                .where((w) => FavoritesService.instance.isFavorite(w.id))
                .toList();

            return ListView(
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
              children: [
                const Text(
                  'Favorites',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF171717),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${favorites.length} saved '
                  '${favorites.length == 1 ? 'word' : 'words'}',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF746B5D),
                  ),
                ),
                const SizedBox(height: 20),
                if (favorites.isEmpty)
                  const _EmptyState()
                else
                  for (final word in favorites) ...[
                    WordCard(word: word),
                    const SizedBox(height: 18),
                  ],
              ],
            );
          },
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Column(
        children: const [
          Icon(Icons.favorite_border, size: 44, color: Color(0xFF858078)),
          SizedBox(height: 12),
          Text(
            'No favorites yet',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
          ),
          SizedBox(height: 4),
          Text(
            'Tap the heart on any word to save it here.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Color(0xFF746B5D)),
          ),
        ],
      ),
    );
  }
}